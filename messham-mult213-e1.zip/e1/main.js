var xkcd = require('xkcd');
 
// Get the current xkcd
xkcd(function (data) {
  console.log(data);
});