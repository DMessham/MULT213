import moment from 'moment';

console.log("Hello, new message!");
console.log("Current time is: " + moment().format('YYYY-MM-DD HH:mm:ss'));